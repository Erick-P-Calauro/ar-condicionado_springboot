package com.ifms.arcondicionado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArCondicionadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArCondicionadoApplication.class, args);
	}

}
