package com.ifms.arcondicionado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArCondicionadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
